package com.CH22_TWO.service;

import java.util.List;
import java.util.Optional;

import com.CH22_TWO.Entity.Student;

public interface Student_service {

	Student saveM(Student student);

	List<Student> findAllM();

	Optional<Student> findByIdM(long id);

	void deleteByIdM(long id);

}
