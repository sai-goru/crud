package com.CH22_TWO.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.CH22_TWO.Entity.Student;

@Repository
public interface studentRepo extends JpaRepository<Student, Long>{

}
