package com.CH22_TWO.service_Implementation;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.CH22_TWO.Entity.Student;
import com.CH22_TWO.Repository.studentRepo;
import com.CH22_TWO.service.Student_service;

@Service
public class Student_serviceImpl implements Student_service {
	
	@Autowired
	private studentRepo stuRepo;

	@Override
	public Student saveM(Student student) {
		return stuRepo.save(student);
	}

	@Override
	public List<Student> findAllM() {
		return stuRepo.findAll();
	}

	@Override
	public Optional<Student> findByIdM(long id) {
		return stuRepo.findById(id);
	}

	@Override
	public void deleteByIdM(long id) {
		stuRepo.deleteById(id);
	}

}
