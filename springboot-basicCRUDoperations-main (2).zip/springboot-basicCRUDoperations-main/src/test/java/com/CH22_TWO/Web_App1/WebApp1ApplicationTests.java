package com.CH22_TWO.Web_App1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebApp1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
